import React from 'react';

class Projects extends React.Component {
    render() {
        return (
            <h2>Coming soon!</h2>
        )
    }
}

export default Projects;
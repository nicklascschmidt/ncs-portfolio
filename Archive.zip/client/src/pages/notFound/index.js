export { default } from "./notFound.js";

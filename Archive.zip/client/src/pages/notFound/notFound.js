import React from 'react';

class NotFound extends React.Component {
    render() {
        return (
            <h2>Sorry, this page doesn't exist.</h2>
        )
    }
}

export default NotFound;
import React from "react";
import Wrapper from '../../components/Wrapper';



class Main extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      
    };
  }

  // componentDidMount = () => {
  //   this.setState({

  //   });
  // };

  // handleChange = event => {
  //   const { name, value } = event.target;
  //   this.setState({
  //     [name]: value
  //   });
  // };


  render() {
    return (

      <Wrapper>
        <h1>Welcome</h1>
        <h4>Apologies, this site is currently under maintenance.</h4>
        <h3>Please come back soon!</h3>
      </Wrapper>
    );
  }
}

export default Main;

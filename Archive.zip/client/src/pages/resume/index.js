export { default } from "./resume.js";

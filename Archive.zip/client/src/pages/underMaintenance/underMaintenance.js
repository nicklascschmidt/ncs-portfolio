import React from "react";


class Main extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      
    };
  }

  render() {
    return (
      <div>
        <h1>Welcome</h1>
        <h4>Apologies, this site is currently under maintenance.</h4>
        <h3>Please come back soon!</h3>
      </div>
    );
  }
}

export default Main;

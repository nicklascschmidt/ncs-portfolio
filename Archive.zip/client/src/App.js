import React from 'react';
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

// pages
import Main from './pages/main';
import NotFound from './pages/notFound';

// css
// import './app-style.css';


class App extends React.Component {
  render() {
    return (
      <Router>
        <div>
          {/* <div>nav</div> */}
          <Switch>
            <Route exact path="/" component={Main} />

            <Route component={NotFound} />
          </Switch>
        </div>
      </Router>
    )
  }
};

export default App;


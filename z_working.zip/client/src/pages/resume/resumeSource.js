export const resumeDropboxLink = 'https://www.dropbox.com/s/2ihp82ko6i8gqrj/NCS_Resume_Mar%202019.pdf?dl=0';
export const resumeImgurLink = 'https://i.imgur.com/uYI94zN.jpg';
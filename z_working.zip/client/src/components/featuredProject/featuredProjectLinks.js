const desktopLinksArray = [
  'https://i.imgur.com/5F3PQ2l.png',
  'https://i.imgur.com/oPuw1Aa.png',
  'https://i.imgur.com/Q7tHguZ.png',
];
const mobileLinksArray = [
  'https://i.imgur.com/cefLCCJ.png',
  'https://i.imgur.com/UeODfx5.png',
  'https://i.imgur.com/xfAtf2H.png',
];

export { desktopLinksArray, mobileLinksArray };